#include <stdio.h>

int main() {
    int contador=0;
    int numero=50,min=1,max=100;
    char simbolo;

    // pergunta inicialmente ao usuário se o número é 50, maior, ou menor.
    printf("O número é %d?\nSe você pensou em um número maior, então digite >\n Se você pensou em um número menor, então digite <\nSe eu acertei, digite =\n", numero);
    // lê o valor e armazena na variável char simbolo
    scanf("%c", &simbolo);
    // incrementa o contador
    contador++;

    // enquanto não tiver acertado o número e digitado o caracter '=', vai continuar no loop
    while (simbolo != '=') {

        // se o número for menor
        if (simbolo == '<') {
            max = numero - 1;
        }
        // se o número for maior
        else if (simbolo == '>') {
            min = numero + 1;

        }
        // fórmula da busca binária
        // ref:https://pt.khanacademy.org/computing/computer-science/algorithms/binary-search/a/binary-search
        numero = min + (max-min) /2;

        // pergunta ao usuário se o número calculado pelo fórmula da busca binária é o correto, maior ou menor
        printf("O número é %d?\nSe você pensou em um número maior, então digite >\n Se você pensou em um número menor, então digite <\n",
               numero);
        // lê a resposta do usuário
        scanf(" %c", &simbolo);
        // incrementa o contador
        contador++;

    }
    // exibe as tentativas do programa em acertar o número do usuário
    printf("Acertei em %d tentativas.", numero);
    return 0;

}


