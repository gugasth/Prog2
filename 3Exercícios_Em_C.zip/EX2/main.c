#include <stdio.h>
#include <ctype.h> // biblioteca que contêm a função toupper
#include <string.h> // biblioteca que contêm a função strlen
int main() {
    char texto[25]; // declara a cadeia de caracteres que armazenará o texto dado pelo usuário
    printf("Digite uma frase!\n"); // solicita ao usuário o texto
    fgets(texto, 24, stdin); // lê o valor do teclado

    for (int i=0; i<strlen(texto);i++) { // percorre os caracteres da string
        if (texto[i] == ' ') { // verifica se o caracter for um espaço, então
            if (islower(texto[i+1])) { // verifica se o caracter depois do espaço é uma letra minuscula
                texto[i + 1] = toupper(texto[i + 1]); // então converte essa letra minuscula em maiuscula
            }
        }
    }



    if (islower(texto[0])){ // verifica se o primeiro caracter é uma minuscula
        texto[0] = toupper(texto[0]); // se for, então transforma em maiuscula
    }

    printf("O texto convertido sera\n%s", texto); // imprime o texto já com as letras iniciais convertidas
    return 0;
}
